/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;
import Modelo.Produto;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author aless
 */
public class ProdutoDAO {
        public List<Produto> getLista(){
        String sql = "select * from produto";
        List<Produto> lista = new ArrayList<>();
        try{
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Produto obj = new Produto();
                obj.setId(rs.getInt("cod"));
                obj.setNome(rs.getString("nome"));
                obj.setPreco(rs.getDouble("preco"));
                lista.add(obj);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
        }
        return lista;
    }
     public boolean salvar(Produto obj){
        if (obj.getId() == null) {
            return incluir(obj);
        } else {
            return alterar(obj);
        }
    }
      public Produto localizar(Integer id) {
        String sql = "select * from produto where cod = ?";
        Produto obj = new Produto();
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                obj.setId(rs.getInt("cod"));
                obj.setNome(rs.getString("nome"));
                obj.setPreco(rs.getDouble("preco"));
                return obj;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
        }
        return null;
    }
    
    private boolean incluir(Produto obj) {
        String sql = "insert into produto (nome, preco) values(?,?)";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setString(1, obj.getNome());
            pst.setDouble(2, obj.getPreco());
            
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Produto incluido com sucesso");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Produto não incluido");
                return false;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
            return false;
        }
    }

    private boolean alterar(Produto obj) {
        String sql = "update produto set nome = ?,preco = ? where cod = ?";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setString(1, obj.getNome());
            pst.setDouble(2, obj.getPreco());
            pst.setInt(3, obj.getId());
            
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Produto alterado com sucesso");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Produto não alterado");
                return false;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
            return false;
        }
    }
    
    public boolean remover(Produto obj){
        String sql = "delete from produto where cod = ?";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, obj.getId());
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Produto excluido com sucesso");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Produto não excluido");
                return false;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
            return false;
        }
    }
    
}
