/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;
import Modelo.Venda_Produto;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author aless
 */
public class Venda_ProdutoDAO {
    ProdutoDAO produtodao = new ProdutoDAO();
    VendaDAO vendadao = new VendaDAO();
public List<Venda_Produto> getLista(){
        String sql = "select * from venda_has_produto as vp inner join produto as p on p.cod = vp.Produto_cod; ";
        List<Venda_Produto> lista = new ArrayList<>();
        try{
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Venda_Produto obj = new Venda_Produto();
                obj.setP1(produtodao.localizar(rs.getInt("vp.Produto_cod")));
                obj.setV1(vendadao.localizar(rs.getInt("vp.Venda_idprod")));
                lista.add(obj);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
        }
        return lista;
    }
     public boolean salvar(Venda_Produto obj){
        if (obj.getId() == null) {
            return incluir(obj);
        } else {
            return alterar(obj);
        }
    }
      public Venda_Produto localizar(Integer id) {
        String sql = "select * from Produto where cod = ?";
        Venda_Produto obj = new Venda_Produto();
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                obj.setId(rs.getInt("cod"));
                obj.setP1(produtodao.localizar(rs.getInt("cod")));
                obj.setV1(vendadao.localizar(rs.getInt("idprod")));
                return obj;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
        }
        return null;
    }
    
    private boolean incluir(Venda_Produto obj) {
        String sql = "insert into venda(idprod,Funcionário_idFunc,Cliente_id,valorvenda) values (?, ?, ?, ?);";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, obj.getId());
            pst.setInt(2, obj.getP1().getId());
            pst.setInt(3, obj.getV1().getId());
            
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Vnda incluida com sucesso");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Venda não incluida");
                return false;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
            return false;
        }
    }

    private boolean alterar(Venda_Produto obj) {
        String sql = "update venda set idprod = ?,valorvenda = ? where cliente_id = ?";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, obj.getId());
            pst.setDouble(2, obj.getP1().getId());
            pst.setInt(3, obj.getV1().getId());
            
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Venda alterada com sucesso");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Venda não alterada");
                return false;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
            return false;
        }
    }
    
    public boolean remover(Venda_Produto obj){
        String sql = "delete from venda_has_produto where id = ?";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, obj.getId());
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Venda excluida com sucesso");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Venda não excluida");
                return false;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
            return false;
        }
    }
}
