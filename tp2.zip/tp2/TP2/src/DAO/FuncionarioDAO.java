/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Modelo.Dados;
import Modelo.Funcionario;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author aless
 */
public class FuncionarioDAO {
    public List<Funcionario> getLista(){
        String sql = "select * from funcionario";
        List<Funcionario> lista = new ArrayList<>();
        try{
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Funcionario obj = new Funcionario();
                obj.setId(rs.getInt("idfunc"));
                obj.setNome(rs.getString("nome"));
                obj.setUser(rs.getString("usuario"));
                obj.setSenha(rs.getString("senha"));
                lista.add(obj);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
        }
        return lista;
    }
     public boolean salvar(Funcionario obj){
        if (obj.getId() == null) {
            return incluir(obj);
        } else {
            return alterar(obj);
        }
    }
      public Funcionario localizar(Integer id) {
        String sql = "select * from funcionario where idfunc = ?";
        Funcionario obj = new Funcionario();
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                obj.setId(rs.getInt("idfunc"));
                obj.setNome(rs.getString("nome"));
                obj.setUser(rs.getString("usuario"));
                obj.setSenha(rs.getString("senha"));
                return obj;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
        }
        return null;
    }
    
    private boolean incluir(Funcionario obj) {
        String sql = "insert into funcionario (nome, usuario, senha) values(?,?,?)";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setString(1, obj.getNome());
            pst.setString(2, obj.getUser());
            pst.setString(3, obj.getSenha());
            
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "funcionário incluido com sucesso");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "funcionário não incluido");
                return false;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
            return false;
        }
    }

    private boolean alterar(Funcionario obj) {
        String sql = "update funcionario set nome = ?, usuario = ?, senha = ? where idfunc = ?";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setString(1, obj.getNome());
            pst.setString(2, obj.getUser());
            pst.setString(3, obj.getSenha());
            pst.setInt(4, obj.getId());
            
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "funcionário alterado com sucesso");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "funcionário não alterado");
                return false;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
            return false;
        }
    }
    
    public boolean remover(Funcionario obj){
        String sql = "delete from funcionario where idfunc = ?";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, obj.getId());
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "funcionário excluido com sucesso");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "funcionário não excluido");
                return false;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
            return false;
        }
    }
    
}
