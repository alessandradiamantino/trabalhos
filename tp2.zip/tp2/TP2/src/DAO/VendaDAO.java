/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;
import Modelo.Venda;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author aless
 */
public class VendaDAO {
    ClienteDAO clientedao = new ClienteDAO();
    FuncionarioDAO funcionariodao = new FuncionarioDAO();
public List<Venda> getLista(){
        String sql = "select * from venda";
        List<Venda> lista = new ArrayList<>();
        try{

            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Venda obj = new Venda();
                obj.setId(rs.getInt("idvenda"));
                obj.setE1(clientedao.localizar(rs.getInt("idfunc")));
                obj.setF1(funcionariodao.localizar(rs.getInt("cliente_id")));
                obj.setValor(rs.getDouble("valorvenda"));
                lista.add(obj);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
        }
        return lista;
    }
     public boolean salvar(Venda obj){
        if (obj.getId() == null) {
            return incluir(obj);
        } else {
            return alterar(obj);
        }
    }
     public Venda localizar(Integer id) {
        String sql = "select * from venda where idprod = ?";
        Venda obj = new Venda();
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                obj.setId(rs.getInt("idvenda"));
                obj.setValor(rs.getInt("valorvenda"));
                obj.setE1(clientedao.localizar(rs.getInt("cliente_id")));
                return obj;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
        }
        return null;
    }
    private boolean incluir(Venda obj) {
        String sql = "insert into venda(idfunc,Cliente_id,valorvenda) values (?, ?, ?);";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
           
            pst.setInt(1, obj.getF1().getId());
            pst.setInt(2, obj.getE1().getId());
            pst.setDouble(3, obj.getValor());
            
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Venda incluida com sucesso");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Venda não incluida");
                return false;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
            return false;
        }
    }
    //opcional
    private boolean alterar(Venda obj) {
        String sql = "update venda set idvenda = ?,valorvenda = ? where cliente_id = ?";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, obj.getId());
            pst.setDouble(2, obj.getValor());
            pst.setInt(3, obj.getE1().getId());
            
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Venda alterada com sucesso");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Venda não alterada");
                return false;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
            return false;
        }
    }
    //opcional
    public boolean remover(Venda obj){
        String sql = "delete from venda where idprod = ?";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, obj.getId());
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Venda excluida com sucesso");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Venda não excluida");
                return false;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
            return false;
        }
    }
    
}
