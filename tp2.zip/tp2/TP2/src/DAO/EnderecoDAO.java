/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Modelo.Cliente;
import Modelo.Dados;
import Modelo.Endereco_Cli;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author aless
 */
public class EnderecoDAO {
    ClienteDAO clientedao = new ClienteDAO();
    
      public List<Endereco_Cli> getLista(){          
        String sql = "select * from enderecocli inner join cliente on cliente.id = enderecocli.cliente_id";
        List<Endereco_Cli> lista = new ArrayList<>();
        try{
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Endereco_Cli obj = new Endereco_Cli();
                obj.setRua(rs.getString("rua"));
                obj.setBairro(rs.getString("bairro"));
                obj.setCidade(rs.getString("cidade"));
               // obj.setNum(rs.getInt("numerocasa"));
                obj.setC1(clientedao.localizar(rs.getInt("cliente_id")));
                lista.add(obj);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
        }
        return lista;
    }
     public boolean salvar(Endereco_Cli obj){
        if (obj.getId() == null) {
            return incluir(obj);
        } else {
            return alterar(obj);
        }
    }
     public Endereco_Cli localizar(Integer id) {
        String sql = "select * from enderecocli where Cliente_id = ?";
        Endereco_Cli obj = new Endereco_Cli();
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                obj.setId(rs.getInt("cliente_id"));
                obj.setBairro(rs.getString("bairro"));
                obj.setRua(rs.getString("rua"));
                obj.setCidade(rs.getString("cidade"));
                //obj.setNum(rs.getInt("numerocasa"));
                obj.setC1(clientedao.localizar(rs.getInt("cliente_id")));
                return obj;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
        }
        return null;
    }
    private boolean incluir(Endereco_Cli obj) {
        String sql = "insert into enderecocli (rua, bairro, cidade,  cliente_id) values(?,?,?,?) ";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setString(1, obj.getRua());
            pst.setString(2, obj.getBairro());
            pst.setString(3, obj.getCidade());
//            pst.setInt(4, obj.getNum());
            pst.setInt(4, obj.getC1().getId());
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Endereço incluido com sucesso");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Endereço não incluido");
                return false;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
            return false;
        }
    }

    private boolean alterar(Endereco_Cli obj) {
        String sql = "update enderecocli set rua = ?, bairro = ?, cidade = ? where cliente.id = ?";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setString(1, obj.getRua());
            pst.setString(2, obj.getBairro());
            pst.setString(3, obj.getCidade());
         //   pst.setInt(4, obj.getNum());
            
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Endereço alterado com sucesso");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Endereço não alterado");
                return false;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
            return false;
        }
    }
    
    public boolean remover(Endereco_Cli obj){
        String sql = "delete from enderecocli where cliente_id = ?";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, obj.getId());
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "endereço excluido com sucesso");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "endereço não excluido");
                return false;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
            return false;
        }
    }
    
}
