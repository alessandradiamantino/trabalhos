/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Modelo.Cliente;
import Modelo.Dados;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author aless
 */
public class ClienteDAO {
     public List<Cliente> getLista(){
        String sql = "select * from cliente";
        List<Cliente> lista = new ArrayList<>();
        try{
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Cliente obj = new Cliente();
                obj.setId(rs.getInt("id"));
                obj.setNome(rs.getString("nome"));
                obj.setUnome(rs.getString("u_nome"));
                obj.setTelefone(rs.getInt("telefone"));
                lista.add(obj);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
        }
        return lista;
    }
     public boolean salvar(Cliente obj){
        if (obj.getId()== null) {
            return incluir(obj);
        } else {
            return alterar(obj);
        }
    }
      public Cliente localizar(Integer id) {
        String sql = "select * from cliente where id = ?";
        Cliente obj = new Cliente();
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                obj.setId(rs.getInt("id"));
                obj.setNome(rs.getString("nome"));
                obj.setUnome(rs.getString("u_nome"));
                obj.setTelefone((rs.getInt("telefone")));
                return obj;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
        }
        return null;
    }
      public Cliente BuscarUltimo(){
         String sql = "select * from cliente order by id desc limit 1";
        Cliente obj = new Cliente();
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                obj.setId(rs.getInt("id"));
                obj.setNome(rs.getString("nome"));
                obj.setUnome(rs.getString("u_nome"));
                obj.setTelefone((rs.getInt("telefone")));
                return obj;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
        }
        return null;
      }
    
    public boolean incluir(Cliente obj) {
        String sql = "insert into cliente (nome, u_nome, telefone) values(?,?,?)";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
          
            pst.setString(1, obj.getNome());
            pst.setString(2, obj.getUnome());
            pst.setInt(3, obj.getTelefone());
            
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Cliente incluido com sucesso");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Cliente não incluido");
                return false;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
            return false;
        }
    }

    private boolean alterar(Cliente obj) {
        String sql = "update cliente set nome = ?, u_nome = ?, telefone = ? where id = ?";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setString(1, obj.getNome());
            pst.setString(2, obj.getUnome());
            pst.setInt(3, obj.getTelefone());
            pst.setInt(4, obj.getId());
            
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Cliente alterado com sucesso");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Cliente não alterado");
                return false;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
            return false;
        }
    }

    public boolean remover(Cliente obj){
        String sql = "delete from cliente where id = ?";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, obj.getId());
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Cliente excluido com sucesso");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Cliente não excluido");
                return false;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL: " + e.getMessage());
            return false;
        }
    }
    
}
