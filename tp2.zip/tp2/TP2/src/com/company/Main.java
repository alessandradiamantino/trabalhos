package com.company;

import DAO.ClienteDAO;
import DAO.EnderecoDAO;
import DAO.FuncionarioDAO;
import DAO.ProdutoDAO;
import DAO.VendaDAO;
import DAO.Venda_ProdutoDAO;
import Modelo.Cliente;
import Modelo.Endereco_Cli;
import Modelo.Funcionario;
import Modelo.Produto;
import Modelo.Venda;
import Modelo.Venda_Produto;

public class Main {
    public static void main(String[] args) {

  ClienteDAO c1 = new ClienteDAO();
  c1.incluir(new Cliente(8,"aaa", "vvv", 394522));
   /*     //cliente
        Cliente c1 = new Cliente();
        c1.setTelefone(12345648);
        c1.setNome("Alessandra");
        c1.setUnome("Costa");

        Cliente c2 = new Cliente();
        c2.setNome("José");
        c2.setUnome("Rodrigues");
        c2.setTelefone(45454654);

        ClienteDAO cd = new ClienteDAO();

        cd.salvar(c1);
        cd.salvar(c2);
        
        //update
        Cliente c3 = new Cliente();
        c3.setId(1);
        c3.setTelefone(2345783);
        c3.setNome("Joana");
        c3.setUnome("Costa");
        cd.salvar(c3);


        for (Cliente cliente : cd.getLista())
        {
            System.out.println(cliente);
            System.out.println("\n");
        }

        System.out.println("\n\n\n");


//endereço

        Endereco_Cli ec = new Endereco_Cli();
        ec.setBairro("Alvorada");
        ec.setCidade("Peçanha");
        ec.setNum(21);
        ec.setRua("Av. Juarez V. da Silva");
        ec.setC1(c1);
        
        Endereco_Cli ec2 = new Endereco_Cli();
        ec2.setBairro("Alvorada");
        ec2.setCidade("Peçanha");
        ec2.setNum(505);
        ec2.setRua("Rua BH");
        ec2.setC1(c2);

        EnderecoDAO ed = new EnderecoDAO();
        ed.salvar(ec);
        ed.salvar(ec2);

        for(Endereco_Cli ecli: ed.getLista())
        {
            System.out.println(ecli);
            System.out.println("\n");
        }
        System.out.println("\n\n\n");
//funcionario

        Funcionario f1 = new Funcionario();
        Funcionario f2 = new Funcionario();

        f1.setNome("João");
        f1.setUser("joao");
        f1.setSenha("1234");

        f2.setNome("Ana");
        f2.setUser("ana");
        f2.setSenha("a123");

        FuncionarioDAO fd = new FuncionarioDAO();

        fd.salvar(f1);
        fd.salvar(f2);

        for (Funcionario func: fd.getLista())
        {
            System.out.println(func);
            System.out.println("\n");
        }
        System.out.println("\n\n\n");


        Produto p = new Produto();
        p.setNome("Pão");
        p.setPreco(9.80);

        Produto p2 = new Produto();
        p2.setNome("rosca");
        p2.setPreco(6.50);


        ProdutoDAO pd = new ProdutoDAO();
        pd.salvar(p);
        pd.salvar(p2);


        for (Produto prod: pd.getLista())
        {
            System.out.println(prod + "\n");
        }
        System.out.println("\n\n\n");

//venda

        Venda v = new Venda();
        v.setValor(5.00);
        v.setE1(c2);
        v.setF1(f1);
        
        Venda v2 = new Venda();
        v2.setValor(9.80);
        v2.setE1(c1);
        v2.setF1(f2);

        VendaDAO vd = new VendaDAO();
        vd.salvar(v);
        vd.salvar(v2);

        for (Venda venda: vd.getLista())
        {
            System.out.println(venda + "\n");
        }
        System.out.println("\n\n\n");

//venda produto

        Venda_Produto vp = new Venda_Produto();

        vp.setP1(p2);
        vp.setV1(v2);
        
        Venda_Produto vp2 = new Venda_Produto();

        vp2.setP1(p);
        vp2.setV1(v);

        Venda_ProdutoDAO vpd = new Venda_ProdutoDAO();

        vpd.salvar(vp);
        vpd.salvar(vp2);

        for (Venda_Produto vprod: vpd.getLista())
        {
            System.out.println(vprod + "\n");
        }

        System.out.println("\n\n\n");*/

    }
}


