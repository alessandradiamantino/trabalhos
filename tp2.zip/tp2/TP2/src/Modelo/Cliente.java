package Modelo;

import java.util.Objects;

public class Cliente
{
    private Integer id;
    private String nome;
    private String unome;
    private int telefone;
    public Cliente(int id, String nome, String unome, int telefone) {
       this.id = id;
        this.nome = nome;
        this.unome = unome;
        this.telefone = telefone;
    }

    public Cliente() {
        super();
    }
    

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getUnome() {
        return unome;
    }

    public void setUnome(String unome) {
        this.unome = unome;
    }

    public Integer getTelefone() {
        return telefone;
    }

    public void setTelefone(Integer telefone) {
        this.telefone = telefone;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cliente other = (Cliente) obj;
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return true;
    }

   

 
    @Override
    public String toString() {
        return
                " nome: " + nome + " " + unome +
                ", telefone: " + telefone;
    }

}
