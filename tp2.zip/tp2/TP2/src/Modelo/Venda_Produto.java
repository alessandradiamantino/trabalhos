package Modelo;

import java.util.Objects;

public class Venda_Produto
{
    private Produto p1;
    private Venda v1;
    private Integer id;

        public Venda_Produto(Produto p1, Venda v1) {
        this.id = id;
        this.p1 = p1;
        this.v1 = v1;
    }

    public Venda_Produto() {
        super();
    }
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    
    public Produto getP1() {
        return p1;
    }

    public void setP1(Produto p1) {
        this.p1 = p1;
    }

    public Venda getV1() {
        return v1;
    }

    public void setV1(Venda v1) {
        this.v1 = v1;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 53 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Venda_Produto other = (Venda_Produto) obj;
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Venda_Produto{" +
                "p1=" + p1 +
                ", v1=" + v1 +
                '}';
    }
}
