package Modelo;

import java.util.Objects;

public class Endereco_Cli
{
    private Cliente c1;
    private String rua;
    private String bairro;
    private String cidade;
    private Integer id;

    public Endereco_Cli() {
        super();
    }

    public Endereco_Cli(Cliente c1, String rua, String bairro, String cidade, Integer id) {
        this.c1 = c1;
        this.rua = rua;
        this.bairro = bairro;
        this.cidade = cidade;
        this.id = id;
    }
    

    public Cliente getC1() {
        return c1;
    }

    public void setC1(Cliente c1) {
        this.c1 = c1;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
   

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 83 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Endereco_Cli other = (Endereco_Cli) obj;
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return true;
    }

  
 
    @Override
    public String toString() {
        return "Endereco_Cli{" +
                "c1=" + c1 +
                ", rua='" + rua + '\'' +
                ", bairro='" + bairro + '\'' +
                ", cidade='" + cidade + '\'' +
                ", id=" + id +
                '}';
    }
}
