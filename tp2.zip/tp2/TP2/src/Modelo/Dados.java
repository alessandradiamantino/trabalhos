package Modelo;

import java.util.ArrayList;
import java.util.List;

public class Dados {

    public static List<Endereco_Cli> endereco_cli = new ArrayList<Endereco_Cli>();
    public static List<Funcionario> funcionarios = new ArrayList<Funcionario>();
    public static List<Venda> vendas = new ArrayList<Venda>();
    public static List<Produto> produtos = new ArrayList<Produto>();
    public static List<Venda_Produto> venda_produtos = new ArrayList<Venda_Produto>();
    public static List<Cliente> clientes = new ArrayList<Cliente>();
;
}
